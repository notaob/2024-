#ifndef __pwm_H

#define __pwm_H


#include "include.h"


extern void TIM4_CH4_PWM_Init(u16 per,u16 psc);
void servo_init(void);
void servo_angle(int angle);
#endif
