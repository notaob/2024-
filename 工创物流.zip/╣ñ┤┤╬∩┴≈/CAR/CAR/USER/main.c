#include "include.h"
#include "im948_CMD.h"
#include "bsp_usart.h"
#include "pwm.h"

extern u8 rx_x[4],rx_y[4];
extern int x_s,y_s;
unsigned char position=0;
u8 task_situation=0;
extern u8 TASK1[30],TASK2[3];
extern uint8_t Serial_RxFlag;

int T1[3],T2[3];

void test1(void)//���Ե�һ������
{
			servo_open();
	delay_ms(1000);
		Emm_V5_Pos_Control(1,0,200,100,1600,0,0,UART4);
		delay_ms(2000);
		Put_cmd();
		delay_ms(5000);
		
		code_cal();
		put(1,1);
}

void test2(void)//���Եڶ�������
{
		servo_open();
		delay_ms(1000);
		Emm_V5_Pos_Control(1,0,200,100,1600,0,0,UART4);
		delay_ms(2000);
		PutS_cmd();
		delay_ms(5000);	
		code_calS();
		put(1,1);
}

void test3(void)
{
	
}


int main(void)
{  

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	
	delay_init(168);

	usart_init();
	servo_init();

	delay_ms(2000);
	Emm_V5_Origin_Trigger_Return(1, 0,0,UART4);
	delay_ms(1000);
/*

		servo_open();
	delay_ms(1000);
		Emm_V5_Pos_Control(1,0,200,100,1600,0,0,UART4);
		delay_ms(2000);
		Put_cmd();
		delay_ms(5000);
		
		code_cal();
		put(1,1);
*/

	
	
	while(1)                                                                                                                                                                
	{


	motor_position(position);
		if(task_situation==0)position++;
	//	if(position==)task_situation=1;

	}
}
