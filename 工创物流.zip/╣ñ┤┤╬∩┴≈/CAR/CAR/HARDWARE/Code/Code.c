#include "include.h"
extern u8 rx_x[4],rx_y[4];
int x[4],y[4];
int x_s,y_s;
extern u8 TASK1[30],TASK2[3];
extern u8 count;
extern int T1[3],T2[3];
u8 t1,t2,stage;
extern u8 Serial_RxFlag;
void Code_cmd(void)
{
	printf("main.t0.txt=\"%s\"\xff\xff\xff",TASK1);
	for (char i = 4; i < 7; i++) {TASK2[count] = TASK1[i];count++;}
	usart_SendByte(USART1,'1');
	delay_ms(50);
	 usart_SendCmd(USART1,TASK1,3);
	delay_ms(50);
	 usart_SendCmd(USART1,TASK2,3);
	delay_ms(50);

}

void task_cal(void)
{
	for(int i=0;i<3;i++)
	{
		
		T1[i]=TASK1[i]-0x30;
		T2[i]=TASK2[i]-0x30;
		
	}
}
void Pick_cmd(void)
{

	usart_SendByte(USART1,'2');
	delay_ms(50);
}
void PickS_cmd(void)
{
	usart_SendByte(USART1,'4');
	delay_ms(50);
}
void Put_cmd(void)
{
	usart_SendByte(USART1,'3');
		delay_ms(50);
	stage=1;
}
void PutS_cmd(void)
{
	usart_SendByte(USART1,'6');
		delay_ms(50);
	stage=1;
}
void code_cal(void)
{
	for(int i=0;i<4;i++)
	{
		
		x[i]=rx_x[i]-0x30;
		
		y[i]=rx_y[i]-0x30;		
	}
	x_s=x[1]*100+x[2]*10+x[3];
	y_s=y[1]*100+y[2]*10+y[3];
	if(x[0]==0){x_s=-x_s;}
	if(y[0]==0){y_s=-y_s;}

		printf("main.n0.val=%d\xff\xff\xff",x_s);
		delay_ms(10);
		printf("main.n1.val=%d\xff\xff\xff",y_s);
	delay_ms(10);
		if(Serial_RxFlag==1){
			x_move(100,(x_s-40)*8);
			delay_ms(2000);

			y_move(100,(y_s-50)*8);
			delay_ms(1000);
			Serial_RxFlag=0;
			
		}

}

void code_calS(void)
{
	for(int i=0;i<4;i++)
	{
		
		x[i]=rx_x[i]-0x30;
		
		y[i]=rx_y[i]-0x30;		
	}
	x_s=x[1]*100+x[2]*10+x[3];
	y_s=y[1]*100+y[2]*10+y[3];
	if(x[0]==0){x_s=-x_s;}
	if(y[0]==0){y_s=-y_s;}

		printf("main.n0.val=%d\xff\xff\xff",x_s);
		delay_ms(10);
		printf("main.n1.val=%d\xff\xff\xff",y_s);
	delay_ms(10);
	if(Serial_RxFlag==1){
	x_move(100,(x_s+35)*8);
	delay_ms(2000);

	y_move(100,(y_s-87)*8);
delay_ms(1000);
		Serial_RxFlag=0;
	}

	
}
