#ifndef __Code_H
#define __Code_H
#include "include.h"
void Code_cmd(void);
void Pick_cmd(void);
void PickS_cmd(void);
void Put_cmd(void);
void code_calS(void);
void task_cal(void);
void code_cal(void);
void PutS_cmd(void);

#endif
