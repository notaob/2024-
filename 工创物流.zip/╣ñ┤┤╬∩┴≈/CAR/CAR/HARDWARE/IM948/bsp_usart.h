#ifndef __BSP_USART_H

#define __BSP_USART_H


#include "usart.h"

extern uint8_t rx_byte;


#endif

