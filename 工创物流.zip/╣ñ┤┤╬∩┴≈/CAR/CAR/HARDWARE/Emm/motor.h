#ifndef __MOTOR_H
#define __MOTOR_H
#include "include.h"
void motor_position(unsigned char position);
void motor_init(void);
void motor_stop(void);

void pick_grand(int count, int dir,int angle);
void put(int time,int count);

void x_move(int v,int s);
void y_move(int v,int s);
void z_move(int v,int s);
void corner(unsigned char count);
void mix_move(int x,int y,int z,int s);
void servo_open(void);
void servo_close(void);
#endif
