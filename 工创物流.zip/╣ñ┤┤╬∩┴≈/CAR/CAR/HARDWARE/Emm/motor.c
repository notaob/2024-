
#include "include.h"
#include "im948_CMD.h"
#include "bsp_usart.h"
#include "pwm.h"
#include "usart.h"
#include "Code.h"
extern unsigned char En_usart_flag,En_motor_flag,code_flag,Pick_flag,rx_flag;
extern uint8_t Serial_RxFlag;
extern unsigned char TASK1[3],TASK2[3];
extern int T1[3],T2[3];
int plate=4400;
u8 Speed=0;

int TargetA,TargetB,TargetC,TargetD;
u8 dir_a=0,dir_b=0,dir_c=1,dir_d=1;

void motor_init()
{
		Emm_V5_En_Control(1,1,0,USART3);
		delay_ms(1);
		Emm_V5_En_Control(2,1,0,USART3);
		delay_ms(1);
		Emm_V5_En_Control(3,1,0,USART3);
		delay_ms(1);
		Emm_V5_En_Control(4,1,0,USART3);
		delay_ms(1);
	
}

void motor_stop()
{
		Emm_V5_Stop_Now(1,0,USART3);
		delay_ms(1);
		Emm_V5_Stop_Now(2,0,USART3);
		delay_ms(1);
		Emm_V5_Stop_Now(3,0,USART3);
		delay_ms(1);
		Emm_V5_Stop_Now(4,0,USART3);
		delay_ms(1);
}


void Move_Transfrom(double Vx,double Vy,double Vz)
{
	TargetA=Vx+Vy-Vz;
	TargetB=Vx-Vy-Vz;
	TargetC=Vx+Vy+Vz;
	TargetD=Vx-Vy+Vz;
	if(TargetA>0)dir_a=0;
	if(TargetB>0)dir_b=0;
	if(TargetC>0)dir_c=1;
	if(TargetD>0)dir_d=1;
	if(TargetA<0){dir_a=1;TargetA=-TargetA;}
	if(TargetB<0){dir_b=1;TargetB=-TargetB;}
	if(TargetC<0){dir_c=0;TargetC=-TargetC;}
	if(TargetD<0){dir_d=0;TargetD=-TargetD;}
}

void motor_cmd_x(int s)
{
	
		Emm_V5_Pos_Control(4, dir_a, TargetA,125, s,0,0,USART3);//a
		delay_ms(1);
		Emm_V5_Pos_Control(2, dir_b, TargetB,125, s,0,0,USART3);//b
		delay_ms(1);
		Emm_V5_Pos_Control(1, dir_c, TargetC,125, s,0,0,USART3);//c
		delay_ms(1);
		Emm_V5_Pos_Control(3, dir_d, TargetD,125, s,0,0,USART3);//d
}
void motor_cmd_y(int s)
{
	
		Emm_V5_Pos_Control(4, dir_a, TargetA,50, s,0,0,USART3);//a
		delay_ms(1);
		Emm_V5_Pos_Control(2, dir_b, TargetB,50, s,0,0,USART3);//b
		delay_ms(1);
		Emm_V5_Pos_Control(1, dir_c, TargetC,50, s,0,0,USART3);//c
		delay_ms(1);
		Emm_V5_Pos_Control(3, dir_d, TargetD,50, s,0,0,USART3);//d
}
void motor_cmd_z(int s)
{
	
		Emm_V5_Pos_Control(4, dir_a, TargetA,50, s,0,0,USART3);//a
		delay_ms(1);
		Emm_V5_Pos_Control(2, dir_b, TargetB,50, s,0,0,USART3);//b
		delay_ms(1);
		Emm_V5_Pos_Control(1, dir_c, TargetC,50, s,0,0,USART3);//c
		delay_ms(1);
		Emm_V5_Pos_Control(3, dir_d, TargetD,50, s,0,0,USART3);//d
}


void x_move(int v,int s)
{
if(s<0){s=-s;v=-v;}
		Move_Transfrom(v,0,0);
		motor_cmd_x(s);
}

void y_move(int v,int s)
{
	if(s<0){s=-s;v=-v;}
		Move_Transfrom(0,v,0);
		motor_cmd_y(s);
}

void z_move(int v,int s)
{
	if(s<0){s=-s;v=-v;}
		Move_Transfrom(0,0,v);
		motor_cmd_z(s);
}

void servo_open(void)
{
	servo_angle(1700);
}

void servo_close(void)
{
	servo_angle(1180);
}

void servo_pick(void)
{
	servo_angle(1900);
}

void up(int distance)
{
		Emm_V5_Pos_Control(2,0,400,230,distance,0,0,UART4);
}


void down(int distance)
{
	Emm_V5_Pos_Control(2,1,400,230,distance,0,0,UART4);
}

void pick_plate(int count,unsigned char dir,int angle,int time)
{
	
if(count!=1)
{
				servo_pick();
				down(plate);
				delay_ms(1000);
}

	if(time==1&&count==1)
	{

			Pick_cmd();
			
	}
	else if(time==2&&count==1)
	{

			PickS_cmd();
			
	}
	else
	{

			usart_SendByte(USART1,'9');
	}

	while(Pick_flag==0);

	Pick_flag=0;


	servo_close();
	delay_ms(500);
	up(plate);
	delay_ms(1000);
	Emm_V5_Pos_Control(1,dir,200,50,angle,0,0,UART4);
	delay_ms(1000);
	down(3000);
	delay_ms(1000);
	servo_angle(1400);
	delay_ms(500);
	up(3000);
	delay_ms(1000);
	if(count<3)
	{

		Emm_V5_Pos_Control(1,0,200,50,1600,1,0,UART4);
				delay_ms(1000);


	}
	if(count==3)
	{	
	Emm_V5_Origin_Trigger_Return(1, 0,0,UART4);
	}

}

void pick_grand(int count,int dir,int angle)
{
	if(count==1)
	{
		Emm_V5_Pos_Control(1,0,200,50,1600,0,0,UART4);
			delay_ms(1000);
	}
	servo_open();

	down(11300);
	delay_ms(1000);
	servo_close();
	delay_ms(500);
	up(11300);
	delay_ms(1000);
	Emm_V5_Pos_Control(1,dir,200,50,angle,0,0,UART4);
	delay_ms(1000);
	down(3000);
	delay_ms(500);
	servo_angle(1400);

	up(3000);
	delay_ms(500);
	if(count<3)
	{
	Emm_V5_Pos_Control(1,0,200,50,1600,1,0,UART4);

	}
	if(count==3)
	{Emm_V5_Origin_Trigger_Return(1,0,0,UART4);}
}

void put(int time,int count)//0��ʱ,1˳ʱ
{
	int num;
	int dis=2800;//****************************
	if(count==1)num=11300;
	if(count==2)num=4500;
	
	if(time==1)
	{
		
		Emm_V5_Pos_Control(1,0,200,50,1200,0,0,UART4);
		delay_ms(1000);
		down(dis);//***************************
		delay_ms(1000);
		servo_close();
		delay_ms(500);
		up(dis);//********************************
		delay_ms(500);
		Emm_V5_Pos_Control(1,1,200,50,1200,0,0,UART4);
		
		delay_ms(500);

		down(num);
		delay_ms(1500);
		servo_open();

		up(num);
		delay_ms(500);
		
		
	}
	
	if(time==2)
	{
		servo_angle(1400);
		Emm_V5_Pos_Control(1,0,200,50,1600,0,0,UART4);
		delay_ms(1000);	
		down(dis);
		delay_ms(1000);
		servo_close();
		delay_ms(500);
		up(dis);
		delay_ms(500);
		
		Emm_V5_Pos_Control(1,1,200,50,1600,0,0,UART4);
		delay_ms(500);	
				

		down(num);
		delay_ms(1500);
		servo_open();

		up(num);
		delay_ms(500);

	}
	
	if(time==3)
	{
		servo_angle(1400);
		Emm_V5_Pos_Control(1,1,200,50,1230,0,0,UART4);
		delay_ms(1000);
		
		down(dis);
		delay_ms(1000);
		servo_close();
		delay_ms(500);
		up(dis);
		delay_ms(500);
		
		Emm_V5_Pos_Control(1,0,200,50,1230,0,0,UART4);
		delay_ms(500);	
		

		down(num);
		delay_ms(1500);
		servo_open();
		up(num);
		delay_ms(500);
		Emm_V5_Pos_Control(1,1,200,50,1600,0,0,UART4);
		delay_ms(1000);
	}

	
}
void corner(unsigned char count)
{
	if(count==1)
	{		
		x_move(400,5000);
		delay_ms(2000);
		z_move(200,4750);
		delay_ms(4000);
		x_move(400,8500);
		delay_ms(3000);
		y_move(-50,1300);
		delay_ms(1000);
	}
		if(count==2)
	{		
		x_move(400,6500);
		delay_ms(2000);
		z_move(100,4750);
		delay_ms(4000);
		x_move(400,8500);
		delay_ms(3000);
		y_move(-50,1300);
		delay_ms(1000);
	}

	
}


void motor_position(unsigned char position)
{
		
	if(position==1)//go to code
	{
		y_move(50,3000);
		delay_ms(2000);
		Emm_V5_Pos_Control(1,0,200,100,1600,1,0,UART4);
		delay_ms(100);
	

	down(plate);
		delay_ms(100);
		
		x_move(200,7000);
			servo_pick();	
		
	}
		
		if(position==2)//go to pick
	{

		while(code_flag==0);

		Code_cmd();
		task_cal();
		x_move(400,12000);
		delay_ms(3000);
		y_move(-100,1250);//************************************************
	delay_ms(1000);
	
	
		pick_plate(1,0,1200,1);

		pick_plate(2,1,1630,1);
	
		pick_plate(3,1,1230,1);
		
		y_move(100,1000);
		
		delay_ms(1000);
	}
	
			if(position==3)//go to second
	{

		corner(1);
		
		servo_open();

		Emm_V5_Pos_Control(1,0,200,50,1600,0,0,UART4);
		
		
		Put_cmd();
		delay_ms(5000);
		code_cal();
		
		
		if((T1[0]-1)!=0)
		{x_move(100,(T1[0]-1)*1950);}
		

		put(1,1);
		
	
		x_move(100,(T1[1]-T1[0])*1950);
	
		

		put(2,1);
		

		x_move(100,(T1[2]-T1[1])*1950);

		
	
		put(3,1);
		
		x_move(100,(T1[0]-T1[2])*1950);
		delay_ms(1000);
		pick_grand(1,0,1200);
		

		x_move(100,(T1[1]-T1[0])*1950);
		delay_ms(1000);
		pick_grand(2,1,1600);
		

		x_move(100,(T1[2]-T1[1])*1950);
		delay_ms(1000);
		pick_grand(3,1,1230);

		x_move(300,(3-T1[2])*1950);
		delay_ms(1000);
		
		y_move(50,1000);//leave
		delay_ms(1000);
		
		

	}
	
			if(position==4)//go to third
	{

		corner(2);
		
		servo_open();

		Emm_V5_Pos_Control(1,0,200,50,1600,0,0,UART4);
		delay_ms(1000);
		
	
		PutS_cmd();
		delay_ms(5000);
		code_calS();
		
		if((T1[0]-1)!=0)
		x_move(100,(T1[0]-1)*1950);

		put(1,1);
		

		x_move(100,(T1[1]-T1[0])*1950);

		put(2,1);
		

		x_move(100,(T1[2]-T1[1])*1950);

		put(3,1);
		
		x_move(-100,(T1[2]-1)*1950);
		delay_ms(1000);
		
	}
				if(position==5)//back to pick
	{
		y_move(100,1200);
		delay_ms(1000);
		x_move(-400,8500);
		delay_ms(3000);
		z_move(-100,4750);
		delay_ms(4000);
		x_move(-400,20000);
		delay_ms(4000);
		z_move(-100,4750);
		delay_ms(4000);
			x_move(-400,5000);
		delay_ms(100);
		Emm_V5_Pos_Control(1,0,200,100,1600,1,0,UART4);
		delay_ms(100);
			servo_open();
	down(plate);
		delay_ms(2000);

		delay_ms(100);
		y_move(-100,800);//****************************************************************

		
		pick_plate(1,0,1200,2);

		pick_plate(2,1,1630,2);
			
		pick_plate(3,1,1230,2);


			y_move(100,800);//*******************************************************************
		
			delay_ms(1000);	
	}
			if(position==6)//again sec
	{
		
		corner(1);
		
		servo_open();

		Emm_V5_Pos_Control(1,0,200,50,1600,0,0,UART4);
		
		
		Put_cmd();
		delay_ms(5000);
		code_cal();
		
		
		if((T2[0]-1)!=0)
		{x_move(100,(T2[0]-1)*1950);}
		

		put(1,1);
		

			x_move(100,(T2[1]-T2[0])*1950);

	

		

		put(2,1);
		
	
			x_move(100,(T2[2]-T2[1])*1950);
	
	

		
	
		put(3,1);
		
		x_move(100,(T2[0]-T2[2])*1950);
		delay_ms(1000);
		pick_grand(1,0,1200);
		

		x_move(100,(T2[1]-T2[0])*1950);
		delay_ms(1000);
		pick_grand(2,1,1600);
		

		x_move(100,(T2[2]-T2[1])*1950);
		delay_ms(1000);
		pick_grand(3,1,1230);
		
		
if(3-T2[2]!=0)
{
		x_move(100,(3-T2[2])*1950);
		delay_ms(2000);
}

		
		y_move(50,1000);//leave
		delay_ms(1000);
		
		
		
	}	

	
				if(position==7)//again third
	{
		corner(2);
		
		
		servo_open();
		Emm_V5_Pos_Control(1,0,200,50,1600,0,0,UART4);

		PutS_cmd();
		delay_ms(5000);
		code_calS();
		
			if((T2[0]-1)!=0)
		{x_move(100,(T2[0]-1)*1950);delay_ms(1000);}		
				put(1,2);
		
			if((T2[1]-T2[0])!=0)
		{x_move(100,(T2[1]-T2[0])*1950);delay_ms(1000);}		
				put(2,2);
		
			if((T2[2]-T2[1])!=0)
		{x_move(100,(T2[2]-T2[1])*1950);delay_ms(1000);}	
		put(3,2);
		
				if((3-T2[2])!=0)
		{x_move(100,(3-T2[2])*1950);delay_ms(1000);}	
		
	}	
			if(position==8)//finish
	{
		y_move(50,1300);
		delay_ms(1500);
		x_move(300,11000);
		delay_ms(4000);
		z_move(100,4750);
		delay_ms(2500);
		x_move(400,20000);
		delay_ms(5000);
		y_move(-50,1000);
		delay_ms(1000);
				x_move(100,2500);
		
			while(1);
	}	

}

